Roaming Gamer Examples
============
This sub-repository contains examples I've written to test various social media features.

 * advanced_facebook - Facebook via the graph library. (facebook.* plugin)
 * basic_email_facebook_twitter - Email, Facebook, Twitter via 'social' plugin.
 * ... more to come
 