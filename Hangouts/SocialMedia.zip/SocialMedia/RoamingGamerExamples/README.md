Roaming Gamer Examples
============
This sub-repository contains examples I've written to test various social media features.

 * advanced_facebook - Facebook via the graph library. (facebook.* plugin)
 * _offline_has_issues - I moved the example 'basic_email_facebook_twitter' offline because it has some problems, and because the example in '~SocialMedia/CoronaResources/fromBlogPosts/android/socialSharingOnAndroid' is fully functional.
 * ... more to come
 