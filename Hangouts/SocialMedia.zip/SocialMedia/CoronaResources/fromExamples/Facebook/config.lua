-- config.lua

application =
{
	content =
	{
	--*** Comment out the lines below for iPad! ***--
		width = 320,
		height = 480,
		scale = "zoomEven"
	},
}