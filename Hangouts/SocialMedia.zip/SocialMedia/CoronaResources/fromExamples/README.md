From Examples
============
This sub-repository contains code extracted directly from the examples that come with Corona.

 * ComposeEmailSMS - Send e-mail or SMS.
 * Facebook - Facebook using the graph library (facebook.* plugin).  (You must provide your own app ID)
 * Twitter - Old OAUTH 1.0 Twitter example.  Not really useful anymore, but still a starting point.
 