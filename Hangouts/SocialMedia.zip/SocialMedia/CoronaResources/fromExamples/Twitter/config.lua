-- config.lua

application =
{
	content =
	{
		width = 320,
		height = 480,
		scale = "letterbox" -- zoom to screen dimensions (may add extra space at top or sides)
	},
}