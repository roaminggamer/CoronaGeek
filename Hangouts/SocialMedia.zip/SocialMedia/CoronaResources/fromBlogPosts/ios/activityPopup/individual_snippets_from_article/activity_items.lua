local items =
{
	{ type = "image", value = { filename = "Icon.png", baseDir = system.ResourceDirectory, } },
	{ type = "string", value = "Hello, World" },
	{ type = "url", value = "http://www.coronalabs.com" },
}