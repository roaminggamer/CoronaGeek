
application = 
{
	content = 
	{ 
		--fps = sysAdjustedFPS,
		fps = 60,
		width = 640,
		height = 960,
		antialias = true,
		scale = "letterbox",
		xAlign = "center",
		yAlign = "center"

	}
}
