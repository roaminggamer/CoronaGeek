Social Media
============
This sub-repository contains code and other resources to help you get started implementing Social media in your games and apps.

 * docs - Various support docs for the Corona Geek talk.
 * Corona Resources - Just what it sounds like.  Stuff Corona already provides.
 * RoamingGamerExamples - Samples I've written for the hangout.
 * offline - A folder for code that didn't work, but still has some hope if I work on it more.
 