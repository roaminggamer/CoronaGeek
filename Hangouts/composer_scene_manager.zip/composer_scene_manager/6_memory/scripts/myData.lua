local myData = {}

myData.lastScene = -1
myData.count = 0

return myData