application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterbox", -- editting setting
		scale = "zoomStretch", -- editting setting
		fps = 60,
	},
}

