This is a simple memory flip-card example.  In this example, we will examine a variety of techniques to achieve:
 * card flipping
 * grid layout
 * shuffling
 * ...

Folder Structure:
 * app/ - The latest code for the game.
 * app_old_versions/ - Old working versions of the code.
 * assets/ - Incoming sound and art assets for the game.
 * docs/ - Any documentation mentioned or used on the hangout.
 * versions/ - Checkpointed versions of the game as we progress.



