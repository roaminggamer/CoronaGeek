This folder contains all OLD builds of the game. 

These builds will be incremently more complete.

To find the most recent version go to this folder: 
\CoronaGeek\Hangouts\ICanMakeThat\MemoryFlipper\app\

The folders containing these builds are named thus:

YYMMDD

* YY = Year
* MM = Month
* DD = Day

