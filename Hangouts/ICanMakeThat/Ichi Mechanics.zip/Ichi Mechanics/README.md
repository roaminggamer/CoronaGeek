Ichi Mechanics
-----------------

The samples in this folder cover:
 * sample1.lua - Wrong way to make a bumper.
 * sample2.lua - One (of several) right ways to make a bumper.
 * talk.lua - Example to go with talk on Corona Geek
 * editor.lua - Simple level editor.  Only has two bumper types, goal, and ball.
 * game.lua - Simple level loader and game.  Only has two bumper types, goal, and ball.



