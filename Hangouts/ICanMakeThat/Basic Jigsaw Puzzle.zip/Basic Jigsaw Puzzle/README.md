Basic Jigsaw Puzzle
-----------------


This folder contains the following:
 * app/ - Funtional example of a jigsaw puzzle app using a simple four-piece puzzle.
 * assets/ - Source assets for this game and a number of extra puzzle source images for you to practice with.
 * docs/ - A document talking about how to make your own puzzle pieces.
 


