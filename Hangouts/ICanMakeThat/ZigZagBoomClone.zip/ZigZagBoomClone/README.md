This is a remake (clone if you will) of the game: Zig Zag Boom by Mudloop.

The purpose of this clone is for 'learning' purposes ONLY.

You can get the original here:

Android: https://play.google.com/store/apps/details?id=com.mudloop.zigzagboom&hl=en

iOS:  https://itunes.apple.com/us/app/zig-zag-boom/id955170175?mt=8

Watch Videos here: 
- https://www.youtube.com/watch?v=hg7m_Ocac2g 
- https://www.youtube.com/watch?v=hDlZ-qlvrO4



Folder Structure:
 * app/ - The latest code for the game.
 * app_old_versions/ - Old working versions of the code.
 * assets/ - Incoming sound and art assets for the game.
 * docs/ - Any documentation mentioned or used on the hangout.
 * versions/ - Checkpointed versions of the game as we progress.



