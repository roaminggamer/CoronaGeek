-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2014 
-- =============================================================
-- 
-- =============================================================
local public = {}

print("Loading game module.")

-- Calculate collision settings once and re-use them in other modules

return public