This is a remake (clone if you will) of the game: They Need To Be Fed (published by YoYoGames).

The purpose of this clone is for 'learning' purposes ONLY.  The goal is to examine the mechanics of the game, not to produce a full reproduction of the original.

'They Need To Be Fed' is the first in what is (as of today) a three game series.  You can find the latest copy of these games on Google Play and the iTunes store.

PLAY THESE GAMES.  They are a lot of fun, challenging, and whimsical.  i.e. What we all wish our games were like.


Homepage For First Game:
 * http://www.venbrux.com/commercial.php


Video(s) here: 
 * They Need To Be Fed (review) - https://www.youtube.com/watch?v=N1QXjOW3kbc 
 * They Need To Be Fed 2 (Launch Trailer) - https://www.youtube.com/watch?v=8wJmf6pzpko 
 * They Need To Be Fed 3 (Launch Trailer) - https://www.youtube.com/watch?v=T9AuSqUgHnc
 * They Need To Be Fed 3 (lonniedos review) - https://www.youtube.com/watch?v=gH9rihpcbHk



Folder Structure:
 * app/ - The latest code for the game.
 * app_old_versions/ - Old working versions of the code.
 * assets/ - Incoming sound and art assets for the game.
 * docs/ - Any documentation mentioned or used on the hangout.
 


