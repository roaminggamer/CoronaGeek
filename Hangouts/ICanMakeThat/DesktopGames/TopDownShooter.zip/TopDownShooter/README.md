This is our first 'Desktop Game'.

We will be making a 'generic' top-down shooter.

No specific details yet on what this game is about.

Folder Structure:
 * app/ - The latest code for the game.
 * app_old_versions/ - Old working versions of the code.
 * assets_incoming/ - Incoming sound and art assets for the game.
 * docs/ - Any documentation mentioned or used on the hangout.
 

