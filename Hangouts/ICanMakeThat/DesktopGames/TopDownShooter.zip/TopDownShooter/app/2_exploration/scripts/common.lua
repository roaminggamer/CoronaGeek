local common = {}


-- World Settings
common.gridSize 	= 160
common.worldSize 	= 80 -- 40 x 40 Grids

common.gridColors = { {1,1,1,0.2}, {0,1,1,0.2}, }
common.gridColors2 = { {1,1,1,0.2}, {1,0,1,0.2}, }


return common