application = {
	content = {
		width = 640,
		height = 960, 
		scale = "zoomStretch", 
		fps = 60, -- need this for smoother transitions
	},
}

