http://soundbible.com/tags-zombie.html

Zombie Kill You.wav - http://soundbible.com/1041-Zombie-Kill-You.html
Zombie Attack Walk.wav - http://soundbible.com/1030-Zombie-Attack-Walk.html
Zombie Moan.wav - http://soundbible.com/1035-Zombie-Moan.html
Archer.wav - http://soundbible.com/1032-Zombie-Rising.html
Bow Fire.wav - http://soundbible.com/1780-Bow-Fire-Arrow.html
died.wav - http://soundbible.com/1623-Dun-Dun-Dun.html

