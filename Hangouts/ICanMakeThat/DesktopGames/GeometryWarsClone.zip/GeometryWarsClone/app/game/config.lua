-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2015 
-- =============================================================
-- This content produced for Corona Geek Hangouts audience.
-- You may use any and all contents in this example to make a game or app.
-- =============================================================

application = {
	content = {
		--width = 1920,
		--height = 1080,      
		width = 768,
		height = 1024,
		scale = "letterbox",
      --scale = "adaptive",
		fps = 60
		--fps = 30
	},
}

