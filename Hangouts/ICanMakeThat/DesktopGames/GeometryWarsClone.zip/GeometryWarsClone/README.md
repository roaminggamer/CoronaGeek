This is our second 'Desktop Game'.

We will be making a 'clone' the (awesome) twin-stick shooter:

"Geometry Wars Retro Evolved"




