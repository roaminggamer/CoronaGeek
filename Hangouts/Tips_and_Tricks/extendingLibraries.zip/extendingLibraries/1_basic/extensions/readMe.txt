These extensions were taken from my free library: SSK Corona and modified for a Talk on Corona Geek.

Get the originals here:

https://github.com/roaminggamer/SSKCorona

