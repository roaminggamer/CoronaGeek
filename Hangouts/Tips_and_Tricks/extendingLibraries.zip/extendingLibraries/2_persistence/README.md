Requires SSK
============

This sample requires SSK.  I included a copy, but you may want to get the latest version here:


Get it here: https://github.com/roaminggamer/SSKCorona

