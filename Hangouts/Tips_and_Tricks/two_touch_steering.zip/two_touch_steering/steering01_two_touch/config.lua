application = {
	content = {
		width = 320,
		height = 480, 
		scale = "letterbox", -- editting setting
		fps = 30,
	},
}

