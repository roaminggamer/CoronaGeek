-- =============================================================
-- Copyright Roaming Gamer, LLC. 2009-2015 
-- =============================================================
-- This content produced for Corona Geek Hangouts audience.
-- You may use any and all contents in this example to make a game or app.
-- =============================================================

application = {
	content = {
		width 	= 320,
		height 	= 480,
		scale 	= "letterbox",
		fps = 30
	},
}

