application = {
	content = {
		width = 640,
		height = 960, 
		scale = "letterbox",  -- letterbox, zoomEven, zoomStretch, none, adaptive
		fps = 60, -- 30, 60
	},
}

